
# cmake options: TARGET_C_ARCH / TARGET_CPP_ARCH:
#   and optionally:  TARGET_C_EXTRA TARGET_CXX_EXTRA
#
# provided:
#   - function: target_set_c_arch_flags(<target>)    # uses options TARGET_C_ARCH and TARGET_C_EXTRA
#   - function: target_set_cxx_arch_flags(<target>)  # uses options TARGET_CXX_ARCH and TARGET_CXX_EXTRA
#   - macro:    target_set_cxx_arch_option(<target> <gcc/clang_march> <gcc/clang_extra> <msvc_arch>)
#
# see https://en.wikichip.org/wiki/x86/extensions
# and https://gcc.gnu.org/onlinedocs/gcc/x86-Options.html
#   for gcc specific architecture options
# and https://docs.microsoft.com/en-us/cpp/build/reference/arch-x64
# or  https://docs.microsoft.com/en-us/cpp/build/reference/arch-x86
#   for msvc specific architecture options

# https://en.wikichip.org/wiki/arm/versions
# https://en.wikipedia.org/wiki/Raspberry_Pi
# https://gcc.gnu.org/onlinedocs/gcc/ARM-Options.html#ARM-Options
# https://en.wikipedia.org/wiki/Comparison_of_ARMv7-A_cores
# https://en.wikipedia.org/wiki/Comparison_of_ARMv8-A_cores

# arm32_rpi1 untested
#   -mcpu=arm1176jzf-s -mfloat-abi=hard -mfpu=vfp         -mtune=arm1176jzf-s
# arm32_rpi2 untested
#   "-march=armv7-a"   "-mfloat-abi=hard" "-mfpu=neon-vfpv4"
#   "-march=armv8-a"   "-mfloat-abi=hard" "-mfpu=neon-vfpv4"
# arm32_rpi3 with "armv7-a" tested on Raspbian GNU/Linux 10 (buster), 32-bit  => MIPP test reports: NEONv1, 128 bits
#   "-march=armv7-a"   "-mfloat-abi=hard" "-mfpu=neon-vfpv4"
# arm32_rpi3 with "armv8-a" tested on Raspbian GNU/Linux 10 (buster), 32-bit  => MIPP test reports: NEONv1, 128 bits
#   "-march=armv8-a"   "-mfloat-abi=hard" "-mfpu=neon-vfpv4"
# arm32_rpi3 with "armv8-a" tested on Raspbian GNU/Linux 10 (buster), 32-bit  => MIPP test reports: NEONv1, 128 bits
#   "-march=armv8-a"   "-mfloat-abi=hard" "-mfpu=neon-vfpv4" "-mtune=cortex-a53"
# arm32_rpi4 untested
#   RPi 4 Model B:    Cortex-A72  =>  "-mtune=cortex-a72"  ?
#   "-mcpu=cortex-a72 -mfloat-abi=hard -mfpu=neon-fp-armv8 -mneon-for-64bits  -mtune=cortex-a72"

set(MSVC_EXTRA_OPT_none "")
set(GCC_EXTRA_OPT_none "")
set(GCC_EXTRA_OPT_neon_vfpv4    "-mfloat-abi=hard" "-mfpu=neon-vfpv4")
set(GCC_EXTRA_OPT_neon_rpi3_a53 "-mfloat-abi=hard" "-mfpu=neon-vfpv4" "-mtune=cortex-a53")
set(GCC_EXTRA_OPT_neon_rpi4_a72 "-mfloat-abi=hard" "-mfpu=neon-fp-armv8" "-mtune=cortex-a72")
set(GCC_EXTRA_OPT_apple_m1      "-mcpu=apple-m1")

# pffft is compiled with the toolchain's default target flags, plus
# TARGET_C_ARCH / TARGET_C_EXTRA if set; on WebAssembly,
# target_set_c_arch_flags() adds its own flags instead. pf_float.h /
# pf_double.h select the SIMD backend from the compiler's predefined macros
# (__SSE__, __ARM_NEON, __ALTIVEC__, ...). E.g. the Android NDK enables NEON
# for armeabi-v7a by default, so pffft uses NEON there; Debian's armhf gcc
# needs -mfpu=neon or a neon_* preset for it.
#
# These targets get extra handling, recognised by PFFFT_TARGET_PROCESSOR:
#   - WebAssembly: target_set_c_arch_flags() adds -msimd128 for WASM SIMD,
#     and -mrelaxed-simd with PFFFT_USE_WASM_RELAXED_SIMD, in place of
#     TARGET_C_ARCH / TARGET_C_EXTRA. Checked first, as Emscripten's
#     toolchain file reports "x86".
#   - x86: the FMA reminder and the baseline check below, the /arch choices
#     offered for MSVC, and the build host's /arch level as the MSVC default
#     (native_arch.cmake).
#   - 32-bit ARM A-profile, i.e. Cortex-A cores: the note on gcc's NEON
#     loads and stores below.
#
# PFFFT_TARGET_PROCESSOR is the lower-case name of the target processor:
#   - compilers for the MSVC ABI (cl, clang-cl, clang --target=*-windows-msvc):
#     the compiler's own target, CMAKE_C_COMPILER_ARCHITECTURE_ID: "x64",
#     "x86", "arm64", "arm64ec", "armv7". Unless a toolchain file sets it,
#     CMAKE_SYSTEM_PROCESSOR is the host's there, e.g. "AMD64" in a Visual
#     Studio -A ARM64 build on x64. CMake 3.20 and later report ARM64EC;
#     older ones report it as "x64".
#   - otherwise CMAKE_SYSTEM_PROCESSOR, whatever the platform or toolchain file
#     calls the target: uname -m on Linux ("x86_64", "i686", "armv7l"),
#     uname -p on FreeBSD ("amd64", "i386"), "AMD64" / "x86" for MinGW on
#     Windows, "armv7-a" / "i686" for the Android NDK, "armv8l" for 32-bit
#     ARM code on a 64-bit Linux kernel.
if ((CMAKE_C_COMPILER_ID STREQUAL "MSVC" OR CMAKE_C_SIMULATE_ID STREQUAL "MSVC")
    AND CMAKE_C_COMPILER_ARCHITECTURE_ID)
    string(TOLOWER "${CMAKE_C_COMPILER_ARCHITECTURE_ID}" PFFFT_TARGET_PROCESSOR)
else()
    string(TOLOWER "${CMAKE_SYSTEM_PROCESSOR}" PFFFT_TARGET_PROCESSOR)
endif()
if (EMSCRIPTEN OR (PFFFT_TARGET_PROCESSOR MATCHES "^wasm"))
    set(PFFFT_TARGET_IS_WASM TRUE)
elseif (PFFFT_TARGET_PROCESSOR MATCHES "^(x86|x86_64|x64|amd64|i[3-6]86)$")
    set(PFFFT_TARGET_IS_X86 TRUE)
elseif (PFFFT_TARGET_PROCESSOR MATCHES "^armv7(-?a|h?l)?$|^armv8l$")
    set(PFFFT_TARGET_IS_ARMV7 TRUE)
endif()

# Top-level builds default to the build host's architecture, see native_arch.cmake
include(${CMAKE_CURRENT_LIST_DIR}/native_arch.cmake)
foreach (_pffft_lang C CXX)
    if (DEFINED TARGET_${_pffft_lang}_ARCH)
        set(_pffft_${_pffft_lang}_arch_default "none")
    else()
        pffft_native_arch_default(${_pffft_lang} _pffft_${_pffft_lang}_arch_default)
    endif()
endforeach()

# cmake options - depending on C/C++ compiler
# gcc/clang: TARGET_<lang>_ARCH takes any -march value of the compiler as
# free text; TARGET_<lang>_EXTRA offers the presets defined above, each for
# its own target. MSVC/clang-cl: TARGET_<lang>_ARCH offers the /arch levels
# on x86. HELPSTRING and STRINGS are set explicitly, as set(... CACHE ...)
# keeps those of an existing build directory.
set(GCC_EXTRA_VALUES "none;neon_vfpv4;neon_rpi3_a53;neon_rpi4_a72;apple_m1")
# MSVC and clang-cl /arch levels; "native" picks the build host's level
set(MSVC_ARCH_VALUES "none;native;SSE2;AVX;AVX2;AVX512")
set(_pffft_march_desc "target architecture (-march), e.g. native, x86-64, haswell, armv8-a, armv7-a; none: the compiler's default")
set(_pffft_extra_desc "preset of additional options: neon_vfpv4, neon_rpi3_a53, neon_rpi4_a72 for 32-bit ARM hard-float; apple_m1 for Apple arm64; none")

# A parent project may set TARGET_<lang>_ARCH / _EXTRA as normal variables
# before add_subdirectory(pffft), e.g. set(TARGET_C_ARCH x86-64). Those are
# the values in effect. But creating a cache entry removes a normal variable
# of the same name (see save_normal_variable.cmake): in a fresh build
# directory, and whenever _pffft_drop_choice_list() recreates an entry. The
# options below therefore save such a normal variable first and restore it
# afterwards.
include(${CMAKE_CURRENT_LIST_DIR}/save_normal_variable.cmake)

# _pffft_drop_choice_list(<cache entry>)
# A build directory configured by an older pffft, or for another target,
# may hold a list of choices for the entry. CMake has no way to remove a
# single cache property, so the entry is recreated with its current value.
macro(_pffft_drop_choice_list entry)
    get_property(_pffft_has_list CACHE ${entry} PROPERTY STRINGS SET)
    if (_pffft_has_list)
        get_property(_pffft_value CACHE ${entry} PROPERTY VALUE)
        unset(${entry} CACHE)
        set(${entry} "${_pffft_value}" CACHE STRING "")
    endif()
endmacro()

# _pffft_gcc_clang_options(<C|CXX> <display name>)
# WebAssembly gets neither option, as target_set_c_arch_flags() applies its
# own flags there.
macro(_pffft_gcc_clang_options lang langname)
    if (NOT PFFFT_TARGET_IS_WASM)
        _pffft_save_normal(TARGET_${lang}_ARCH)
        _pffft_save_normal(TARGET_${lang}_EXTRA)
        _pffft_drop_choice_list(TARGET_${lang}_ARCH)
        set(TARGET_${lang}_ARCH "${_pffft_${lang}_arch_default}" CACHE STRING "")
        set_property(CACHE TARGET_${lang}_ARCH PROPERTY HELPSTRING "gcc/clang ${langname} ${_pffft_march_desc}")
        set(TARGET_${lang}_EXTRA "none" CACHE STRING "")
        set_property(CACHE TARGET_${lang}_EXTRA PROPERTY HELPSTRING "gcc/clang ${langname} ${_pffft_extra_desc}")
        set_property(CACHE TARGET_${lang}_EXTRA PROPERTY STRINGS ${GCC_EXTRA_VALUES})
        _pffft_restore_normal(TARGET_${lang}_ARCH)
        _pffft_restore_normal(TARGET_${lang}_EXTRA)
    endif()
endmacro()

# _pffft_msvc_options(<C|CXX> <display name>)
# MSVC and clang-cl. The /arch choices are offered for x86 only.
macro(_pffft_msvc_options lang langname)
    _pffft_save_normal(TARGET_${lang}_ARCH)
    _pffft_save_normal(TARGET_${lang}_EXTRA)
    if (NOT PFFFT_TARGET_IS_X86)
        _pffft_drop_choice_list(TARGET_${lang}_ARCH)
    endif()
    set(TARGET_${lang}_ARCH "${_pffft_${lang}_arch_default}" CACHE STRING "")
    set_property(CACHE TARGET_${lang}_ARCH PROPERTY HELPSTRING "msvc target ${langname} architecture (/arch), e.g. native or AVX2 on x86, armv8.2 on ARM64")
    if (PFFFT_TARGET_IS_X86)
        set_property(CACHE TARGET_${lang}_ARCH PROPERTY STRINGS ${MSVC_ARCH_VALUES})
    endif()
    set(TARGET_${lang}_EXTRA "none" CACHE STRING "msvc additional options")
    _pffft_restore_normal(TARGET_${lang}_ARCH)
    _pffft_restore_normal(TARGET_${lang}_EXTRA)
endmacro()

pffft_msvc_frontend(C _pffft_C_msvc)
if (_pffft_C_msvc)
    _pffft_msvc_options(C "C")
elseif (CMAKE_C_COMPILER_ID MATCHES "^(GNU|Clang|AppleClang)$")
    _pffft_gcc_clang_options(C "C")
else()
    message(WARNING "unsupported C compiler '${CMAKE_C_COMPILER_ID}', see https://cmake.org/cmake/help/latest/variable/CMAKE_LANG_COMPILER_ID.html")
endif()

pffft_msvc_frontend(CXX _pffft_CXX_msvc)
if (_pffft_CXX_msvc)
    _pffft_msvc_options(CXX "C++")
elseif (CMAKE_CXX_COMPILER_ID MATCHES "^(GNU|Clang|AppleClang)$")
    _pffft_gcc_clang_options(CXX "C++")
else()
    message(WARNING "unsupported C++ compiler '${CMAKE_CXX_COMPILER_ID}', see https://cmake.org/cmake/help/latest/variable/CMAKE_LANG_COMPILER_ID.html")
endif()

######################################################
# x86: FMA is opt-in and easy to miss.
#
# The SSE-float and AVX-double VMADD/VMSUB macros lower to true FMA only when
# the compiler guarantees FMA3 -- gcc/clang via -march=haswell or later, MSVC
# via /arch:AVX2. Without it every fused op costs a separate multiply plus add,
# which in the frequency-domain multiply loops means 20 floating point
# operations per iteration instead of 12 (measured on gcc 12 and clang 14,
# x86-64 and i686, float and double alike).
#
# Top-level builds default to the build host's architecture, which includes
# FMA3 where the host has it. The baseline ISA (TARGET_C_ARCH=none, used for
# packages) deliberately stays without it: FMA3 needs Haswell (2013) or
# Piledriver, and requiring it would break older CPUs. So just say so.
#
# "none" adds no flags, so it means the compiler's default ISA, which need not
# be baseline x86-64: GCC on GitHub's ubuntu-26.04 runners emits x86-64-v3
# (AVX2, FMA) code without any flags. Ask the compiler, with CMAKE_C_FLAGS,
# whether it already enables more than SSE2; then a "none" build is not
# portable, and the baseline ISA audit (tests/check_isa_baseline.py) does not
# apply to it. -DTARGET_C_ARCH=x86-64 selects the baseline explicitly.
set(PFFFT_C_DEFAULT_ABOVE_BASELINE FALSE)
if (PFFFT_TARGET_IS_X86 AND NOT _pffft_C_msvc AND CMAKE_SIZEOF_VOID_P EQUAL 8
    AND ( ("${TARGET_C_ARCH}" STREQUAL "") OR ("${TARGET_C_ARCH}" STREQUAL "none") ))
    include(CheckCSourceCompiles)
    # CMAKE_C_FLAGS may change between configures: check every time
    unset(PFFFT_C_DEFAULT_IS_BASELINE CACHE)
    set(CMAKE_REQUIRED_QUIET ON)
    check_c_source_compiles("
#if defined(__SSE3__) || defined(__AVX__)
#  error the compiler targets more than baseline x86-64 by default
#endif
int main(void) { return 0; }
" PFFFT_C_DEFAULT_IS_BASELINE)
    unset(CMAKE_REQUIRED_QUIET)
    if (NOT PFFFT_C_DEFAULT_IS_BASELINE)
        set(PFFFT_C_DEFAULT_ABOVE_BASELINE TRUE)
        message(STATUS "TARGET_C_ARCH='${TARGET_C_ARCH}': the C compiler targets more than"
                       " baseline x86-64 by default (SSE3 or AVX without flags), so this"
                       " build needs a matching CPU; for a portable build use"
                       " -DTARGET_C_ARCH=x86-64 -DTARGET_CXX_ARCH=x86-64")
    endif()
endif()
if (PFFFT_TARGET_IS_X86 AND NOT PFFFT_C_DEFAULT_ABOVE_BASELINE)
    set(_pffft_have_fma FALSE)
    if (_pffft_C_msvc)
        set(_pffft_fma_arch "AVX2")
        if ("${TARGET_C_ARCH}" MATCHES "AVX2|AVX512|AVX10|native")
            set(_pffft_have_fma TRUE)
        endif()
    else()
        set(_pffft_fma_arch "haswell")
        # "native" is resolved by the compiler on the build machine, so whether
        # it implies FMA is unknown here -- stay quiet rather than guess wrong
        if ( ("${TARGET_C_ARCH}" STREQUAL "haswell") OR ("${TARGET_C_ARCH}" STREQUAL "native") )
            set(_pffft_have_fma TRUE)
        endif()
    endif()
    if (NOT _pffft_have_fma)
        message(STATUS "TARGET_C_ARCH='${TARGET_C_ARCH}' has no FMA;"
                       " use -DTARGET_C_ARCH=${_pffft_fma_arch} for ~40% fewer FP ops"
                       " in the convolution loops (requires Haswell/Piledriver or later)")
    endif()
endif()

######################################################
# ARMv7: gcc moves 128-bit NEON vectors in 64-bit pieces.
#
# Not a gcc bug. float32x4_t is specified to be laid out as a NEON register
# stored with VSTM, which on big-endian differs from what VST1 produces, so for
# a plain v4sf array access gcc restricts itself to the layout-compatible forms:
# vld1.64/vst1.64, or a vldr/vstr pair whenever a nonzero immediate offset is
# needed, since vld1.64 has no offset addressing mode. Any loop touching a
# pointer more than once per iteration hits the latter. clang takes a different
# position and uses vld1.32 for the same code. See GCC PR43725 comment 1.
#
# Measured with gcc 12.2 over the whole float translation unit: 1600 vldr/vstr
# and 344 vld1/vst1, against clang 14's 181 and 797 -- about twice the
# load/store operations for the same bytes, spread over ~19 functions. No flag
# changes it (14 combinations tried), and gcc 16.1.0 behaves like 12.2. The
# alternative to switching compilers would be to load/store through
# vld1q_f32()/vst1q_f32() intrinsics, which this library does not do.
if (PFFFT_TARGET_IS_ARMV7 AND CMAKE_C_COMPILER_ID STREQUAL "GNU")
    message(STATUS "gcc moves 128-bit NEON vectors in 64-bit pieces on ARMv7"
                   " (see GCC PR43725), roughly doubling load/store work across the"
                   " transform; clang is recommended here (CC=clang CXX=clang++)")
endif()

######################################################

# Clang (18 at least) can reject the feature set -march=native detects on CPUs
# with AVX10.1 ("invalid feature combination: ... +avx10.1-256; will be
# promoted to avx10.1-512"), which is an error with warnings as errors. The
# promotion is what the CPU supports anyway, so silence the warning for
# host-tuned builds.
function(pffft_native_feature_warning lang target arch)
    if (NOT "${arch}" STREQUAL "native" OR NOT CMAKE_${lang}_COMPILER_ID MATCHES "Clang")
        return()
    endif()
    if (lang STREQUAL "C")
        include(CheckCCompilerFlag)
        check_c_compiler_flag(-Winvalid-feature-combination PFFFT_C_HAS_WFEATURE_COMBINATION)
        set(_have ${PFFFT_C_HAS_WFEATURE_COMBINATION})
    else()
        include(CheckCXXCompilerFlag)
        check_cxx_compiler_flag(-Winvalid-feature-combination PFFFT_CXX_HAS_WFEATURE_COMBINATION)
        set(_have ${PFFFT_CXX_HAS_WFEATURE_COMBINATION})
    endif()
    if (_have)
        target_compile_options(${target} PRIVATE "-Wno-invalid-feature-combination")
    endif()
endfunction()

function(target_set_c_arch_flags target)
    # WebAssembly SIMD (Emscripten or WASI-SDK / plain clang)
    if (PFFFT_TARGET_IS_WASM)
        target_compile_options(${target} PRIVATE "-msimd128")
        if (PFFFT_USE_WASM_RELAXED_SIMD)
            message(STATUS "WebAssembly target: enabling WASM SIMD + Relaxed SIMD for C target ${target}")
            target_compile_options(${target} PRIVATE "-mrelaxed-simd")
        else()
            message(STATUS "WebAssembly target: enabling WASM SIMD for C target ${target}")
        endif()
        return()
    endif()
    if ( ("${TARGET_C_ARCH}" STREQUAL "") OR ("${TARGET_C_ARCH}" STREQUAL "none") )
        message(STATUS "TARGET_C_ARCH not set for target ${target}, using default")
    else()
        pffft_msvc_frontend(C _msvc)
        if (_msvc)
            # MSVC and clang-cl: there is no /arch:native, so use the host's level
            set(_arch "${TARGET_C_ARCH}")
            if ("${_arch}" STREQUAL "native")
                pffft_msvc_host_arch(_arch)
            endif()
            if ("${_arch}" STREQUAL "none")
                message(STATUS "TARGET_C_ARCH=native for target ${target}: build host has no AVX, using default")
            else()
                target_compile_options(${target} PRIVATE "/arch:${_arch}")
                message(STATUS "C ARCH for target ${target} set: ${_arch}")
            endif()
        elseif ( (CMAKE_C_COMPILER_ID STREQUAL "GNU") OR (CMAKE_C_COMPILER_ID STREQUAL "Clang") OR (CMAKE_C_COMPILER_ID STREQUAL "AppleClang") )
            target_compile_options(${target} PRIVATE "-march=${TARGET_C_ARCH}")
            pffft_native_feature_warning(C ${target} "${TARGET_C_ARCH}")
            message(STATUS "C ARCH for target ${target} set: ${TARGET_C_ARCH}")
        else()
            message(WARNING "unsupported C compiler '${CMAKE_C_COMPILER_ID}' for target_set_c_arch_flags(), see https://cmake.org/cmake/help/latest/variable/CMAKE_LANG_COMPILER_ID.html")
        endif()
    endif()

    if ( ("${TARGET_C_EXTRA}" STREQUAL "") OR ("${TARGET_C_EXTRA}" STREQUAL "none") )
        message(STATUS "TARGET_C_EXTRA not set for target ${target}, using default")
    else()
        if ( (CMAKE_C_COMPILER_ID STREQUAL "GNU") OR (CMAKE_C_COMPILER_ID STREQUAL "Clang") OR (CMAKE_C_COMPILER_ID STREQUAL "AppleClang"))
            target_compile_options(${target} PRIVATE "${GCC_EXTRA_OPT_${TARGET_C_EXTRA}}")
            message(STATUS "C additional options for target ${target} set: ${GCC_EXTRA_OPT_${TARGET_C_EXTRA}}")
        elseif (CMAKE_C_COMPILER_ID MATCHES "MSVC")
            # target_compile_options(${target} PRIVATE "${MSVC_EXTRA_OPT_${TARGET_C_EXTRA}}")
            message(STATUS "C additional options for target ${target} not usable with MSVC")
        else()
            message(WARNING "unsupported C compiler '${CMAKE_C_COMPILER_ID}' for target_set_c_arch_flags(), see https://cmake.org/cmake/help/latest/variable/CMAKE_LANG_COMPILER_ID.html")
        endif()
    endif()

endfunction()

function(target_set_cxx_arch_flags target)
    # WebAssembly SIMD (Emscripten or WASI-SDK / plain clang)
    if (PFFFT_TARGET_IS_WASM)
        target_compile_options(${target} PRIVATE "-msimd128")
        if (PFFFT_USE_WASM_RELAXED_SIMD)
            message(STATUS "WebAssembly target: enabling WASM SIMD + Relaxed SIMD for C++ target ${target}")
            target_compile_options(${target} PRIVATE "-mrelaxed-simd")
        else()
            message(STATUS "WebAssembly target: enabling WASM SIMD for C++ target ${target}")
        endif()
        return()
    endif()
    if ( ("${TARGET_CXX_ARCH}" STREQUAL "") OR ("${TARGET_CXX_ARCH}" STREQUAL "none") )
        message(STATUS "TARGET_CXX_ARCH not set for target ${target}, using default")
    else()
        pffft_msvc_frontend(CXX _msvc)
        if (_msvc)
            # MSVC and clang-cl: there is no /arch:native, so use the host's level
            set(_arch "${TARGET_CXX_ARCH}")
            if ("${_arch}" STREQUAL "native")
                pffft_msvc_host_arch(_arch)
            endif()
            if ("${_arch}" STREQUAL "none")
                message(STATUS "TARGET_CXX_ARCH=native for target ${target}: build host has no AVX, using default")
            else()
                target_compile_options(${target} PRIVATE "/arch:${_arch}")
                message(STATUS "C++ ARCH for target ${target} set: ${_arch}")
            endif()
        elseif ( (CMAKE_CXX_COMPILER_ID STREQUAL "GNU") OR (CMAKE_CXX_COMPILER_ID STREQUAL "Clang") OR (CMAKE_CXX_COMPILER_ID STREQUAL "AppleClang") )
            target_compile_options(${target} PRIVATE "-march=${TARGET_CXX_ARCH}")
            pffft_native_feature_warning(CXX ${target} "${TARGET_CXX_ARCH}")
            message(STATUS "C++ ARCH for target ${target} set: ${TARGET_CXX_ARCH}")
        else()
            message(WARNING "unsupported C++ compiler '${CMAKE_CXX_COMPILER_ID}' for target_set_cxx_arch_flags(), see https://cmake.org/cmake/help/latest/variable/CMAKE_LANG_COMPILER_ID.html")
        endif()
    endif()
    if ( ("${TARGET_CXX_EXTRA}" STREQUAL "") OR ("${TARGET_CXX_EXTRA}" STREQUAL "none") )
        message(STATUS "TARGET_CXX_EXTRA not set for target ${target}, using default")
    else()
        if ( (CMAKE_CXX_COMPILER_ID STREQUAL "GNU") OR (CMAKE_CXX_COMPILER_ID STREQUAL "Clang") OR (CMAKE_CXX_COMPILER_ID STREQUAL "AppleClang") )
            target_compile_options(${target} PRIVATE "${GCC_EXTRA_OPT_${TARGET_CXX_EXTRA}}")
            message(STATUS "C++ additional options for target ${target} set: ${GCC_EXTRA_OPT_${TARGET_CXX_EXTRA}}")
        elseif (CMAKE_CXX_COMPILER_ID MATCHES "MSVC")
            # target_compile_options(${target} PRIVATE "${MSVC_EXTRA_OPT_${TARGET_CXX_EXTRA}}")
            message(STATUS "C++ additional options for target ${target} not usable with MSVC")
        else()
            message(WARNING "unsupported C compiler '${CMAKE_C_COMPILER_ID}' for target_set_c_arch_flags(), see https://cmake.org/cmake/help/latest/variable/CMAKE_LANG_COMPILER_ID.html")
        endif()
    endif()
endfunction()


macro(target_set_cxx_arch_option target gcc_clang_arch gcc_clang_extra msvc_arch )
    if ( (CMAKE_CXX_COMPILER_ID STREQUAL "GNU") OR (CMAKE_CXX_COMPILER_ID STREQUAL "Clang") OR (CMAKE_CXX_COMPILER_ID STREQUAL "AppleClang") )

        if ( NOT (("${gcc_clang_arch}" STREQUAL "") OR ("${gcc_clang_arch}" STREQUAL "none") ) )
            target_compile_options(${target} PRIVATE "-march=${gcc_clang_arch}")
            message(STATUS "C++ ARCH for target ${target}: ${gcc_clang_arch}")
        endif()
        if (NOT ( ("${gcc_clang_extra}" STREQUAL "") OR ("${gcc_clang_extra}" STREQUAL "none") ) )
            target_compile_options(${target} PRIVATE "${GCC_EXTRA_OPT_${gcc_clang_extra}}")
            message(STATUS "C++ additional options for target ${target}: ${GCC_EXTRA_OPT_${gcc_clang_extra}}")
        endif()
    elseif (CMAKE_CXX_COMPILER_ID MATCHES "MSVC")
        if ( NOT (("${msvc_arch}" STREQUAL "") OR ("${msvc_arch}" STREQUAL "none") ) )
            target_compile_options(${target} PRIVATE "/arch:${msvc_arch}")
            message(STATUS "C++ ARCH for target ${target} set: ${msvc_arch}")
        endif()
    else()
        message(WARNING "unsupported C++ compiler '${CMAKE_CXX_COMPILER_ID}' for target_set_cxx_arch_option(), see https://cmake.org/cmake/help/latest/variable/CMAKE_LANG_COMPILER_ID.html")
    endif()
endmacro()
